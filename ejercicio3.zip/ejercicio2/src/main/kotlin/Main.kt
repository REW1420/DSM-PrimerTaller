//3.Realizar una aplicación. Solicitar al usuario 3 números enteros y calcular el mayor y menor de ellos.



        fun main() {

            val validar = validar()
            val funsion = funsion()


            println("Ingrese su primer numero")
            val Num1 = readln()!!.toInt()
            println("Ingrese su segundo numero")
            val Num2 = readln()!!.toInt()
            println("Ingrese su tercer numero")
            val Num3 = readln()!!.toInt()


        }

