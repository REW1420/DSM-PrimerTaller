import com.sun.tools.javac.Main
import java.util.*




        open class validar : Main() {
open class funsion()

            var Num1: Int = 0
            var Num2: Int = 0
            var Num3: Int = 0
            var main: Int = 0


            fun validar() {
                //No numero 9, mayor a 0, positivos, no repetir
                if (Num1 % 3 == 0 && Num2 % 3 == 0 && Num3 % 3 == 0) {
                    if (Num1 < 0 || Num2 < 0 || Num3 < 0) {
                        println("Solo ingresar numero positivos")
                        main()
                    } else if (Num1 == 0 || Num2 == 0 || Num3 == 0) {
                        println("solo ingresar numeros mayor a cero")
                        main()
                    } else if (Num1 == Num2 || Num2 == Num3 || Num1 == Num3) {
                        println("Solo numero diferentes")
                        main()
                    } else if ((Num1 == 9 || Num2 == 9) || Num3 == 9) {
                        println("No ingrsar el numero 9")
                        main()
                    }
                }
            }

            private fun main() {
            }

        }




