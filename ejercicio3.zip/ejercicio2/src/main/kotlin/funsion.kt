import java.util.*


class funsion() : validar(){

    fun funsion() {
        //multiplo de tres
        if (Num1 % 3 == 0 && Num2 % 3 == 0 && Num3 % 3 == 0) {
            println("Si cumplen con la condicion de ser multiplos de 3")

            //numero mayor
            if (Num1 > Num2 && Num1 > Num3) {
                println("El numero $Num1 es mayor que $Num2 y $Num3")

                //numero mayor suma 10
                if (Num1 > 5) {
                    println("se suma ya que $Num1 es mayor a 5")
                    val suma = Num1 + 10
                    println("Resultado es $Num1 + 10 es $suma que $Num2 y $Num3")
                } else {
                    println("No se realiza la suma debido a que $Num1 no es el numero mayor a 5")
                }

                if (Num2 > 5) {
                    println("se suma ya que $Num2 es mayor a 5")
                    val suma = Num2 + 10

                    println("Resultado es $Num2 + 10 es $suma que $Num1 y $Num3")
                } else {
                    println("No se realiza la suma debido a que $Num2 no es el numero mayor a 5")
                }

                if (Num3 > 5) {
                    println("se suma ya que $Num3 es mayor a 5")
                    val suma = Num3 + 10

                    println("Resultado es $Num3 + 10 es $suma que $Num1 y $Num2")
                } else {
                    println("No se realiza la suma debido a que $Num3 no es el numero mayor a 100")
                }

                //numero menor
                if (Num1 < Num2 && Num1 < Num3) {
                    println("El numero $Num1 es menor que $Num2 y $Num3")

                    //menor resta 5
                    if (Num1 < 100) {
                        println("se resta ya que $Num1 es menor a 5")
                        val resta = Num1 - 5
                        println("Resultado es $Num1 + 10 es $resta que $Num2 y $Num3")
                    } else {
                        println("No se realiza la resta debido a que $Num1 no es el numero menor a 100")
                    }

                    if (Num2 < 100) {
                        println("se resta ya que $Num2 es menor a 5")
                        val resta = Num2 - 5

                        println("Resultado es $Num2 + 10 es $resta que $Num1 y $Num3")
                    } else {
                        println("No se realiza la resta debido a que $Num2 no es el numero menor a 100")
                    }

                    if (Num3 < 100) {
                        println("se suma ya que $Num3 es mayor a 5")
                        val resta = Num3 - 5

                        println("Resultado es $Num3 + 10 es $resta que $Num1 y $Num2")
                    } else {
                        println("No se realiza la resta debido a que $Num3 no es el numero menor a 100")
                    }
                }
            }
        }

    }

}

